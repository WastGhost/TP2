#ifndef RENTAL_H
#define RENTAL_H

#include "struct.h"

// Functions for managing rentals
Rental createRental();
void displayRental(Rental rental);

#endif
