#ifndef RENTALBLOCK_H
#define RENTALBLOCK_H

#include "struct.h"

// Functions for managing rental blocks with TNOF
TNOF* open_file(char *path, char mode);
void close_file(TNOF *tnof);
void addRental(TNOF *tnof, Rental rental);
int searchRental(TNOF *tnof, int rentalID, Rental *foundRental);
void displayAllRentals(TNOF *tnof);

#endif
