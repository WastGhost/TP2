#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rentalblock.h"
#include "struct.h"
#include "rental.h"



TNOF* open_file(char *path, char mode) {
    TNOF *tnof = (TNOF*)malloc(sizeof(TNOF));
    if (!tnof) return NULL;

    strncpy(tnof->fichier, path, 200);
    FILE *file = (mode == 'N') ? fopen(path, "wb") : fopen(path, "rb+");
    if (!file) {
        free(tnof);
        return NULL;
    }

    if (mode == 'N') {
        tnof->ent.nb_bloc = 0;
        fwrite(&(tnof->ent), sizeof(Entete), 1, file);
    } else {
        fread(&(tnof->ent), sizeof(Entete), 1, file);
    }

    fclose(file);
    return tnof;
}

void close_file(TNOF *tnof) {
    free(tnof);
}

void addRental(TNOF *tnof, Rental rental) {
    RentalBlock block;
    FILE *file = fopen(tnof->fichier, "rb+");

    fseek(file, sizeof(Entete) + (tnof->ent.nb_bloc * sizeof(RentalBlock)), SEEK_SET);
    fread(&block, sizeof(RentalBlock), 1, file);

    if (block.rentalCount < MAX_RENTALS) {
        block.rentals[block.rentalCount++] = rental;
    } else {
        block.rentals[0] = rental;
        block.rentalCount = 1;
        tnof->ent.nb_bloc++;
    }

    fseek(file, sizeof(Entete) + (tnof->ent.nb_bloc * sizeof(RentalBlock)), SEEK_SET);
    fwrite(&block, sizeof(RentalBlock), 1, file);

    fclose(file);
}

void displayAllRentals(TNOF *tnof) {
    RentalBlock block;
    FILE *file = fopen(tnof->fichier, "rb");

    for (int i = 0; i <= tnof->ent.nb_bloc; i++) {
        fseek(file, sizeof(Entete) + (i * sizeof(RentalBlock)), SEEK_SET);
        fread(&block, sizeof(RentalBlock), 1, file);

        for (int j = 0; j < block.rentalCount; j++) {
            displayRental(block.rentals[j]);
        }
    }

    fclose(file);
}
