#include <stdio.h>
#include <string.h>
#include "game.h"

Game createGame() {
    Game game;
    printf("Enter game title: ");
    scanf("%s", game.title);
    printf("Enter rental price: ");
    scanf("%f", &game.rentalPrice);
    return game;
}

void displayGame(Game game) {
    printf("Title: %s\n", game.title);
    printf("Rental Price: $%.2f\n", game.rentalPrice);
}
