#include <stdio.h>
#include <string.h>
#include "customer.h"

Customer createCustomer() {
    Customer customer;
    printf("Enter customer ID: ");
    scanf("%d", &customer.customerID);
    printf("Enter first name: ");
    scanf("%s", customer.firstName);
    printf("Enter last name: ");
    scanf("%s", customer.lastName);
    printf("Enter contact info: ");
    scanf("%s", customer.contactInfo);
    return customer;
}

void displayCustomer(Customer customer) {
    printf("Customer ID: %d\n", customer.customerID);
    printf("Name: %s %s\n", customer.firstName, customer.lastName);
    printf("Contact Info: %s\n", customer.contactInfo);
}
