#include <stdio.h>
#include "rental.h"
#include "customer.h"
#include "game.h"

Rental createRental() {
    Rental rental;
    rental.customer = createCustomer();
    rental.game = createGame();
    printf("Enter rental ID: ");
    scanf("%d", &rental.rentalID);
    printf("Enter rental date (dd mm yyyy): ");
    scanf("%d %d %d", &rental.rentalDate.day, &rental.rentalDate.month, &rental.rentalDate.year);
    printf("Enter return date (dd mm yyyy): ");
    scanf("%d %d %d", &rental.returnDate.day, &rental.returnDate.month, &rental.returnDate.year);
    rental.totalPrice = rental.game.rentalPrice;
    return rental;
}

void displayRental(Rental rental) {
    printf("\nRental ID: %d\n", rental.rentalID);
    displayCustomer(rental.customer);
    displayGame(rental.game);
    printf("Rental Date: %02d/%02d/%d\n", rental.rentalDate.day, rental.rentalDate.month, rental.rentalDate.year);
    printf("Return Date: %02d/%02d/%d\n", rental.returnDate.day, rental.returnDate.month, rental.returnDate.year);
    printf("Total Price: $%.2f\n", rental.totalPrice);
}
