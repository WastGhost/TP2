#ifndef GAME_H
#define GAME_H

#include "struct.h"

// Functions for managing games
Game createGame();
void displayGame(Game game);

#endif
