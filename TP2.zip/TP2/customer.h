#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "struct.h"

// Functions for managing customers
Customer createCustomer();
void displayCustomer(Customer customer);

#endif
