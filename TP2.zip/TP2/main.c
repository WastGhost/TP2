#include <stdio.h>
#include "rental.h"
#include "rentalblock.h"

int main() {
    TNOF *tnof;
    Rental rental;
    int choice;
    char path[100], mode;

    printf("Enter file path: ");
    scanf("%s", path);
    printf("Open mode (A: Open existing, N: New): ");
    scanf(" %c", &mode);

    tnof = open_file(path, mode);
    if (!tnof) {
        printf("Error opening file.\n");
        return 1;
    }

    do {
        printf("\n---- Menu ----\n");
        printf("1. Create a Rental\n");
        printf("2. Display All Rentals\n");
        printf("0. Exit\n");
        printf("Choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                rental = createRental();
                addRental(tnof, rental);
                break;
            case 2:
                displayAllRentals(tnof);
                break;
            case 0:
                printf("Exiting.\n");
                break;
            default:
                printf("Invalid choice.\n");
                break;
        }
    } while (choice != 0);

    close_file(tnof);
    return 0;
}
